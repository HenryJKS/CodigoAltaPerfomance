package exercicio2;


import java.util.Scanner;
import listas.ListaAlunos;

public class PlanilhaAlunos {

	public static void main(String[] args) {
		
		ListaAlunos turma = new ListaAlunos();
		Scanner le = new Scanner(System.in);
		int opcao;
		do {
			System.out.println("0 - Sair");
			System.out.println("1 - Inserir Aluno");
			System.out.println("2 - Remover Aluno");
			System.out.println("3- Pesquisar Aluno");
			System.out.println("  Op��o:  ");
			opcao = le.nextInt();
			
			switch(opcao) {
			case 0:
				System.out.println("Programa encerrado!");
				break;
			case 1:
				System.out.println("Informe o RM do aluno que ser� inserido: ");
				int rm = le.nextInt();
				System.out.println("M�dia: ");
				double media = le.nextDouble();
				Aluno aluno = new Aluno(rm, media);
				turma.insere(aluno);
				turma.show();
				break;
			case 2:
				System.out.println("Informe o RM do aluno para remover: ");
				rm = le.nextInt();
				turma.remove(rm);
				turma.show();
				break;
			case 3:
				System.out.println("Informe o RM do aluno para ser pesquisado");
				rm = le.nextInt();
				double m = turma.select(rm);
				if (m == -1)
					System.out.println("Aluno n�o encontrado na lista");
				else
					System.out.println("A m�dia do aluno � " + m);	
				break;
			default:
				System.out.println("Op��o Invalida");
			}
		} while (opcao != 0);
		le.close();
		
		
		
		
		

	}

}
