package main;
import java.util.Scanner;

import listas.ListaIntCrescente;

public class mainTeste {

	public static void main(String[] args) {
		
		ListaIntCrescente lista = new ListaIntCrescente();
		
		Scanner le = new Scanner(System.in);
		System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
		int valor = le.nextInt();
		
		while(valor >= 0) {
			lista.insere(valor);
			lista.show();
			System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
			valor = le.nextInt();
		}
		
		System.out.println("Quantidade de n�s da lista: " + lista.contaNos());
		
		System.out.println("Qual o valor do limite inferior do intervalo que deseja apresentar?");
		valor = le.nextInt();
		lista.showGreaters(valor);
		
		System.out.println("\n\nInforme o valor positivo para inserir ou negativo para sair: ");
		valor = le.nextInt();
		while(valor >= 0) {
			lista.remove(valor);
			lista.show();
			System.out.println("Informe o valor positivo para inserir ou negativo para sair: ");
			valor = le.nextInt();
		}	
		le.close();
		
		
	
	}

}
