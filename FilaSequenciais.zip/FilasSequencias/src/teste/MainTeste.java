package teste;

import filasSequenciais.FilaSequencialInt;

public class MainTeste {

	public static void main(String[] args) {

		FilaSequencialInt fila = new FilaSequencialInt();
		fila.init();
		
		fila.enqueue(23);
		fila.enqueue(17);
		fila.enqueue(66);
		if (!fila.isEmpty())
			System.out.println("Valor do dado que est� no in�cio da fila " + fila.first());
		if (!fila.isEmpty())
			System.out.println("Valor retirado: " +fila.dequeue());
		if (!fila.isEmpty())
			System.out.println("Valor retirado: " +fila.dequeue());
		if (!fila.isEmpty())
			System.out.println("Valor retirado: " +fila.dequeue());
		if (!fila.isEmpty())
			System.out.println("Valor retirado: " +fila.dequeue());
	}

}
