package Exercicio4;
import java.util.Scanner;

import filasSequenciais.FilaSequencialInt;

public class Processador {

	public static void main(String[] args) {
		FilaSequencialInt filaProcessos = new FilaSequencialInt();
		filaProcessos.init();
		Scanner le = new Scanner(System.in);
		int op;
		do {
			System.out.println("1- Submeta o 1 processo ");
			System.out.println("2- Execute o 1 processo ");
			System.out.println("3- Encerre o programa ");
			op = le.nextInt();
			switch (op) {
			
			case 1: 
				System.out.println("Informe o pid: ");
				int pid = le.nextInt();
				filaProcessos.enqueue(pid);
				break;
			case 2:
				if(!filaProcessos.isEmpty()) {
				pid = filaProcessos.dequeue();
				System.out.println("Processo " + pid + " est� sendo executado");
				System.out.println("Processo foi concluido? (1- Sim/ 2-N�o) ");
				int resp = le.nextInt();
				if (resp == 2)
					filaProcessos.enqueue(pid);
				else
					System.out.println("Processo  " + pid + " foi concluido ");
				}
				break;
			case 3:
				if(!filaProcessos.isEmpty()) {
					System.out.println("H� processor na fila de execu��o.");
				    System.out.println("Deseja encerrar? (1- Sim / 2- N�o)");
				    int resp = le.nextInt();
				    if (resp == 1) {
				    	while (!filaProcessos.isEmpty())
				    		System.out.println("Encerrando o processo "+ filaProcessos.dequeue());
				    	System.out.println("Shutdown....");
				    }
				    else
				    	op = 0;
				}else
					System.out.println("Shutdown...");
				break;
			default:
					System.out.println("Processo inv�lido! ");
			}	
		} while (op != 3);
		
		
		
		
		
		
		
		
		
		
	}

}
